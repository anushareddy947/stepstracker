// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#datatable_pending').DataTable();
});

$(document).ready(function() {
  $('#datatable_active').DataTable();
});
$(document).ready(function() {
  $('#datatable_deactive').DataTable();
});

