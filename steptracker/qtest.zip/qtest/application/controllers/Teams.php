<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Teams extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('Teams_model');
       
    }
	public function index()
	{
        $data['page']='';
        //$data['files']=$this->Main_model->getReports($this->session->id);
		    $this->load->view('team',$data);
	}
    
    public function insertTEAM()
    {
        if($this->input->post('name')!='' && $this->input->post('type')!='')
        {
              $this->Teams_model->insertTeam($_POST);
              $this->session->set_flashdata('success','Team Created successfully.');
              redirect('teams');

        }
    }

}
