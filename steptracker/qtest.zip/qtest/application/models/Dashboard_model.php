<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends CI_Model{

    public function __construct(){
       parent::__construct();
       // $this->db19 = $this->load->database('gitam19', TRUE);
    }
  
  public function getReports($id)
  {
    $sql = "select * from reports where id=$id order by start_time desc";
      $query = $this->db->query($sql);
      return $query->result();
  }

  public function getStatistics()
  {
      $sql = "SELECT count(id) as files,sum(distance) as distance,sum(calories) as calories FROM `reports` where (start_time BETWEEN '".date('Y-m-d',strtotime($this->input->post('start_date')))."' and '".date('Y-m-d',strtotime($this->input->post('end_date')))."') and user_id=".$this->session->id;
        $query = $this->db->query($sql);
      $res=$query->result();
      $kms=number_format(($res[0]->distance/1000),2)." KM";
      $steps=round($res[0]->distance*1.3123);

    echo json_encode(array('kms'=>$kms,'steps'=>$steps,'calories'=>$res[0]->calories,'files'=>$res[0]->files));
  }
}
