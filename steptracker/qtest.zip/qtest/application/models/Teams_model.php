<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Teams_model extends CI_Model{

    public function __construct(){
       parent::__construct();
       // $this->db19 = $this->load->database('gitam19', TRUE);
    }

  public function insertTeam($data){
        
        $this->db->insert('teams', $data);
        $lastid = $this->db->insert_id();
        return $lastid;
    }
  public function getUser($id)
  {
      $sql = "select * from users where id=$id";
      $query = $this->db->query($sql);
      $user=$query->result();
      return $user[0];
  }
    public function updateUser($data){
        $this->db->where('id', $data['id']);
        $result = $this->db->update('users' , $data);
        return $result;
   }
  public function getReports($id)
  {
    $sql = "select * from reports where id=$id order by start_time desc";
      $query = $this->db->query($sql);
      return $query->result();
  }

  public function updateGoal()
  {
    $this->db->query("update users set goal='".$this->input->post('goal')."' where id=".$this->session->id);
    return true;
  }
}
